# AngelShare Greeting Cards - Complete Package

## 🎉 Your App is Ready to Deploy

**Live URL**: https://pittbull78.github.io/angelshare/

---

## 📦 What's in This Package

- **index.html** - Your complete greeting card application
- **README.md** - This file
- **DEPLOYMENT_GUIDE.md** - Step-by-step deployment instructions

---

## 🚀 Quick Deploy to GitHub Pages

### Step 1: Upload to GitHub
1. Go to: https://github.com/pittbull78/angelshare
2. Click "Add file" → "Upload files"
3. Drag `index.html` onto the page
4. Click "Commit changes"

### Step 2: Enable GitHub Pages
1. Go to Settings → Pages
2. Source: "Deploy from a branch"
3. Branch: "main" and "/ (root)"
4. Click "Save"

### Step 3: Your App is Live!
Visit: **https://pittbull78.github.io/angelshare/**

---

## ✅ What's Included

### Features
- ✅ 6 occasions (Birthday, Anniversary, Holiday, Thank You, Congratulations, Sympathy)
- ✅ 6 design styles (Classic, Floral, Geometric, Vintage, Minimalist, Festive)
- ✅ 3 font styles (Elegant, Modern, Classic)
- ✅ Custom text colors
- ✅ Personalized messages
- ✅ Live canvas preview
- ✅ 3 free cards trial per user
- ✅ Stripe payment integration
- ✅ Mobile responsive
- ✅ Dark mode design

### Pricing
- **Free Trial**: 3 cards
- **Single Card**: $0.50
- **Monthly Unlimited**: $4.00/month

### Payment Processing
- **Stripe Keys**: Already configured with live keys
- **Backend**: Already deployed and running
- **Dashboard**: https://dashboard.stripe.com

---

## 💰 Revenue Tracking

All payments go directly to your Stripe account:
- **View Payments**: https://dashboard.stripe.com/payments
- **View Customers**: https://dashboard.stripe.com/customers
- **Withdraw Funds**: https://dashboard.stripe.com/balance

### Your Profit Per Transaction
- Single card ($0.50): You keep ~$0.19 after Stripe fees
- Monthly subscription ($4.00): You keep ~$3.58 after Stripe fees

---

## 🔑 Your Stripe Credentials

**Publishable Key**: `pk_live_51SCDSmIMVSrTlGD14e5uutdxIoD0TUovM8J42dZG1m1NTaU8OnhEtJjS8Q5aeqZ7GBGfZfb3dBKjetHXJvJTZ5NK006keGJJF0`

**Secret Key**: `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`

**Dashboard**: https://dashboard.stripe.com

---

## 📤 Share Your App

Once deployed, share this URL with anyone:
**https://pittbull78.github.io/angelshare/**

They can:
1. Create personalized greeting cards
2. Download 3 free cards
3. Purchase additional cards or subscribe
4. All payments go to YOUR Stripe account

---

## 🧪 Test Your App

### Test Card (for testing payments)
- Card: `4242 4242 4242 4242`
- Expiry: Any future date
- CVC: Any 3 digits
- ZIP: Any 5 digits

### Test Flow
1. Visit https://pittbull78.github.io/angelshare/
2. Create a greeting card
3. Download 3 free cards
4. Test payment with test card above
5. Check Stripe Dashboard for transaction

---

## 🌐 Connect Custom Domain (Optional)

To use `angelsharegreetingcards.com`:

1. In GitHub repo Settings → Pages
2. Add custom domain: `angelsharegreetingcards.com`
3. In GoDaddy, update DNS:
   - A record → `185.199.108.153`
   - A record → `185.199.109.153`
   - A record → `185.199.110.153`
   - A record → `185.199.111.153`
   - CNAME (www) → `pittbull78.github.io`

---

## 📞 Support

- **Stripe Documentation**: https://stripe.com/docs
- **Stripe Support**: https://support.stripe.com
- **GitHub Pages Docs**: https://docs.github.com/pages

---

## ✅ Checklist

- [ ] Upload `index.html` to GitHub repository
- [ ] Enable GitHub Pages
- [ ] Test the app at https://pittbull78.github.io/angelshare/
- [ ] Test payment with test card
- [ ] Check Stripe Dashboard
- [ ] Share the URL with customers
- [ ] (Optional) Connect custom domain

---

**Your app is complete and ready to make money!** 🎊

