# Deployment Guide - AngelShare Greeting Cards

## 🎯 Goal
Deploy your greeting card app to: **https://pittbull78.github.io/angelshare/**

---

## 📋 Prerequisites

- GitHub account (username: pittbull78)
- Repository created: https://github.com/pittbull78/angelshare
- This package with `index.html` file

---

## 🚀 Deployment Steps (5 Minutes)

### Step 1: Go to Your Repository
Visit: **https://github.com/pittbull78/angelshare**

### Step 2: Upload the File

**Option A: Through Web Interface (Easiest)**
1. Click "Add file" button (top right)
2. Click "Upload files"
3. Drag the `index.html` file onto the page
4. Scroll down and click "Commit changes"

**Option B: Create New File**
1. Click "Add file" → "Create new file"
2. Name it: `index.html`
3. Copy and paste the entire content from the `index.html` file
4. Click "Commit changes"

### Step 3: Enable GitHub Pages
1. Click the "Settings" tab (top of repository page)
2. Scroll down and click "Pages" in the left sidebar
3. Under "Source", select:
   - Branch: **main** (or master)
   - Folder: **/ (root)**
4. Click "Save"

### Step 4: Wait for Deployment
- GitHub will show a message: "Your site is ready to be published"
- Wait 1-2 minutes
- Refresh the Pages settings page
- You'll see: "Your site is live at https://pittbull78.github.io/angelshare/"

### Step 5: Test Your App
1. Visit: **https://pittbull78.github.io/angelshare/**
2. Create a greeting card
3. Download 3 free cards
4. Test payment with card: `4242 4242 4242 4242`
5. Check Stripe Dashboard: https://dashboard.stripe.com/payments

---

## ✅ Verification Checklist

- [ ] Repository exists at github.com/pittbull78/angelshare
- [ ] `index.html` file is uploaded
- [ ] GitHub Pages is enabled in Settings
- [ ] Site is live at https://pittbull78.github.io/angelshare/
- [ ] App loads and shows greeting card creator
- [ ] Free download works (3 cards)
- [ ] Payment form appears after 3 free cards
- [ ] Test payment processes successfully
- [ ] Payment appears in Stripe Dashboard

---

## 🔧 Troubleshooting

### "404 - Page Not Found"
- Wait 2-3 minutes after enabling Pages
- Make sure file is named exactly `index.html` (lowercase)
- Check that Pages is enabled in Settings

### "App Loads But Blank Screen"
- Check browser console (F12) for errors
- Make sure you uploaded the complete `index.html` file
- Try clearing browser cache

### "Payment Not Working"
- Check that backend is running: https://4242-iidd0gj4d9r945cr86ybp-fb45ac7b.manusvm.computer/
- Verify Stripe keys in Dashboard
- Check Stripe Dashboard logs for errors

### "Can't Upload File"
- Make sure you're logged into GitHub
- Try using "Create new file" option instead
- Check that repository exists and you have write access

---

## 📤 Sharing Your App

Once deployed, share this URL:
**https://pittbull78.github.io/angelshare/**

### Marketing Ideas
- Share on social media
- Email to friends and family
- Post in greeting card groups
- Add to your email signature
- Create QR code linking to the app

### Track Performance
- **Payments**: https://dashboard.stripe.com/payments
- **Customers**: https://dashboard.stripe.com/customers
- **Revenue**: https://dashboard.stripe.com/balance

---

## 🌐 Custom Domain Setup (Optional)

To use `angelsharegreetingcards.com`:

### In GitHub
1. Settings → Pages → Custom domain
2. Enter: `angelsharegreetingcards.com`
3. Click "Save"

### In GoDaddy
1. Login to GoDaddy.com
2. My Products → Domains → DNS
3. Add these records:

**A Records** (delete existing, add these 4):
```
Type: A, Name: @, Value: 185.199.108.153
Type: A, Name: @, Value: 185.199.109.153
Type: A, Name: @, Value: 185.199.110.153
Type: A, Name: @, Value: 185.199.111.153
```

**CNAME Record**:
```
Type: CNAME, Name: www, Value: pittbull78.github.io
```

### Wait for DNS
- Changes take 5 minutes to 24 hours
- Your app will be live at: `https://angelsharegreetingcards.com`

---

## 💰 Making Money

### Revenue Flow
1. Customer visits your app
2. Creates and downloads 3 free cards
3. Pays $0.50 for additional card OR $4/month for unlimited
4. **Money goes directly to your Stripe account**
5. Withdraw to your bank from Stripe Dashboard

### Pricing Breakdown
- **Single Card**: $0.50 → You earn ~$0.19 (after 2.9% + $0.30 Stripe fee)
- **Monthly**: $4.00 → You earn ~$3.58 (after 2.9% + $0.30 Stripe fee)

### Example Monthly Revenue
- 100 single cards = $19 profit
- 25 monthly subscribers = $89.50 profit
- **Total: $108.50/month**

---

## 📞 Need Help?

- **Stripe Issues**: https://support.stripe.com
- **GitHub Pages**: https://docs.github.com/pages
- **Test Cards**: https://stripe.com/docs/testing

---

**You're ready to deploy and start making money!** 🚀

